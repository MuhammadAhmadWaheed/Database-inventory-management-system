﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class CustomerLogin : Form
    {
        OracleConnection con;
        public CustomerLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == string.Empty || textBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.Open();
                OracleCommand customerlogin = con.CreateCommand();
                customerlogin.CommandText = "SELECT * FROM CUSTOMER where Username = \'" + textBox1.Text.ToString() + "\'and Password =  \'" + textBox2.Text.ToString() + "\'";
                customerlogin.CommandType = CommandType.Text;
                OracleDataReader d = customerlogin.ExecuteReader();
                if (d.Read())
                {
                    this.Hide();
                    CustomerRes res = new CustomerRes();
                    res.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid Details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void CustomerLogin_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            textBox2.UseSystemPasswordChar = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerSignUp s = new CustomerSignUp();
            s.ShowDialog();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }
    }
}
