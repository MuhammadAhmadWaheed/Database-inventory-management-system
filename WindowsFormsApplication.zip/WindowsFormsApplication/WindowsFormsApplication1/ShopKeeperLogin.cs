﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class ShopKeeperLogin : Form
    {
        OracleConnection con;
        public ShopKeeperLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShopKeeperSignUp1 signup1 = new ShopKeeperSignUp1();
            signup1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == string.Empty || textBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.Open();
                OracleCommand shopKlogin = con.CreateCommand();
                shopKlogin.CommandText = "SELECT * FROM SHOPKEEPER where Username = \'" + textBox1.Text.ToString() + "\'and Password =  \'" + textBox2.Text.ToString() + "\'";
                shopKlogin.CommandType = CommandType.Text;
                OracleDataReader d = shopKlogin.ExecuteReader();
                if (d.Read())
                {
                    this.Hide();
                    ManageProductsShopK form = new ManageProductsShopK();
                    ((Label)form.Controls["label7"]).Text = textBox1.Text;
                    form.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Invalid Details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void ShopKeeperLogin_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            textBox2.UseSystemPasswordChar = true;
        }

        private void ShopKPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }
    }
}
