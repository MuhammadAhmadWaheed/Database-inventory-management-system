﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class CustomerRes : Form
    {
        OracleConnection con;
        public CustomerRes()
        {
            InitializeComponent();
        }
        bool check(bool flag)
        {
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if (!(textBox1.Text[i] - '0' >= 0 && textBox1.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ProductID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            if(flag)
            {
                if (numericUpDown1.Value == 0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            return flag;
        }
        private void CustomerRes_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            updateGrid();
            numericUpDown1.Maximum = 1000;
        }
        private void updateGrid()
        {
            con.Open();
            OracleCommand getEmps = con.CreateCommand();
            getEmps.CommandText = "SELECT PRODUCTID,PRODUCTNAME,MANUFACTURERNAME,EXPIRYDATE,PRICE,QUANTITY FROM PRODUCT";
            getEmps.CommandType = CommandType.Text;
            OracleDataReader empDR = getEmps.ExecuteReader();
            DataTable empDT = new DataTable();
            empDT.Load(empDR);
            dataGridView1.DataSource = empDT;
            con.Close();
        }
        bool pr()
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT PRODUCTID FROM PRODUCT";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (!d.Read())
            {
                MessageBox.Show("No products are available in shop.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkDuplicate()
        {
            int id = Int16.Parse(textBox1.Text);
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT QUANTITY FROM CART WHERE PRODUCTID = " + id + "";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Selected product is already added in cart. If you want to update it please update it from cart.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkQuantity()
        {
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (textBox1.Text.ToString() == dataGridView1.Rows[i].Cells[0].Value.ToString())
                {
                    if (Int16.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString()) >= numericUpDown1.Value)
                    {
                        con.Open();
                        OracleCommand insertEmp = con.CreateCommand();
                        insertEmp.CommandText = "UPDATE PRODUCT SET QUANTITY = " + (Int16.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString()) - numericUpDown1.Value) + " WHERE PRODUCTID = " + textBox1.Text + "";
                        int rows = insertEmp.ExecuteNonQuery();
                        con.Close();
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Not enough quantity available.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return false;
                    }
                }
            }
            return true;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                flag = check(flag);
                if(flag && pr())
                {
                    flag = true;
                    flag = checkDuplicate();
                    if(flag && checkQuantity())
                    {
                        con.Open();
                        OracleCommand insertEmp = con.CreateCommand();
                        insertEmp.CommandText = "INSERT INTO CART VALUES((SELECT PRODUCTID FROM PRODUCT WHERE PRODUCTID = " + textBox1.Text.ToString()
                            + "),(SELECT PRODUCTNAME FROM PRODUCT WHERE PRODUCTID = \'" + textBox1.Text.ToString()
                            + "\'),(SELECT MANUFACTURERNAME FROM PRODUCT WHERE PRODUCTID = \'" + textBox1.Text.ToString()
                            + "\'),(SELECT EXPIRYDATE FROM PRODUCT WHERE PRODUCTID = \'" + textBox1.Text.ToString()
                            + "\'),(SELECT PRICE FROM PRODUCT WHERE PRODUCTID = " + textBox1.Text.ToString() + ")," + numericUpDown1.Value.ToString() + ")";
                        insertEmp.CommandType = CommandType.Text;
                        int rows = insertEmp.ExecuteNonQuery();
                        if (rows > 0)
                            MessageBox.Show("Added to Cart.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        con.Close();
                        textBox1.Clear();
                        numericUpDown1.Value = 0;
                        updateGrid();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while performing the operation: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            CustomerLogin login = new CustomerLogin();
            login.ShowDialog();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox2.Text != "")
            {
                OracleCommand cmd = new OracleCommand("SELECT PRODUCTID,PRODUCTNAME,MANUFACTURERNAME,EXPIRYDATE,PRICE FROM PRODUCT WHERE CONCAT(PRODUCTID,CONCAT(PRODUCTNAME,CONCAT(MANUFACTURERNAME,CONCAT(EXPIRYDATE,CONCAT(PRICE,USERNAME))))) LIKE '%" + textBox2.Text.ToString() + "%'", con);
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
                updateGrid();
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Search Products Here") 
            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Search Products Here";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Payment p = new Payment();
            p.ShowDialog();
        }
    }
}
