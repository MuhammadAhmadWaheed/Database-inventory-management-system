﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class Payment : Form
    {
        OracleConnection con;
        public Payment()
        {
            InitializeComponent();
        }
        bool check1(bool flag)
        {
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if (!(textBox1.Text[i] - '0' >= 0 && textBox1.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ProductID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            return flag;
        }
        bool check2(bool flag)
        {
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if (!(textBox1.Text[i] - '0' >= 0 && textBox1.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ProductID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            if(flag)
            {
                if(numericUpDown1.Value<=0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            return flag;
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            CustomerRes res = new CustomerRes();
            res.ShowDialog();
        }

        private void Search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Search.Text != "")
            {
                OracleCommand cmd = new OracleCommand("SELECT * FROM CART WHERE CONCAT(PRODUCTID,CONCAT(PRODUCTNAME,CONCAT(MANUFACTURERNAME,CONCAT(EXPIRYDATE,PRICE)))) LIKE '%" + Search.Text.ToString() + "%'", con);
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
                updateGrid();
        }
        private void updateGrid()
        {
            try
            {
                con.Open();
                OracleCommand getEmps = con.CreateCommand();
                getEmps.CommandText = "SELECT PRODUCTID,PRODUCTNAME,MANUFACTURERNAME,EXPIRYDATE,PRICE,QUANTITY,PRICE*QUANTITY AS TOTALPRICE FROM CART";
                getEmps.CommandType = CommandType.Text;
                OracleDataReader empDR = getEmps.ExecuteReader();
                DataTable empDT = new DataTable();
                empDT.Load(empDR);
                dataGridView1.DataSource = empDT;
                con.Close();
                dataGridView1.AllowUserToAddRows = false;
                label1.Text = "0";
                int total = 0;
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    total += int.Parse(dataGridView1.Rows[i].Cells[6].Value.ToString());
                }
                label1.Text = total.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show("An error occurred while performing the operation: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Search_Leave(object sender, EventArgs e)
        {
            if (Search.Text == "")
            {
                Search.Text = "Search Products Here";
                Search.ForeColor = Color.Silver;
            }
        }

        private void Search_Enter(object sender, EventArgs e)
        {
            if (Search.Text == "Search Products Here")
            {
                Search.Text = "";
                Search.ForeColor = Color.Black;
            }
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            updateGrid();
            label2.Enabled = true;
            textBox1.Enabled = true;
            button1.Enabled = true;
            label3.Enabled = false;
            label4.Enabled = false;
            textBox2.Enabled = false;
            numericUpDown1.Enabled = false;
            button2.Enabled = false;
            numericUpDown1.Maximum = 1000;
        }
        void insert()
        {
            int quantity = 0;
            for(int i=0;i<dataGridView1.Rows.Count;i++)
            {
                if(textBox1.Text==dataGridView1.Rows[i].Cells[0].Value.ToString())
                {
                    quantity = Int16.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString());
                    break;
                }
            }
            con.Open();
            OracleCommand insertEmp = con.CreateCommand();
            insertEmp.CommandText = "UPDATE PRODUCT SET QUANTITY = QUANTITY + " + quantity + " WHERE PRODUCTID = " + textBox1.Text + "";
            insertEmp.CommandType = CommandType.Text;
            int rows = insertEmp.ExecuteNonQuery();
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            insert();
            con.Open();
            OracleCommand insertEmp = con.CreateCommand();
            insertEmp.CommandText = "DELETE FROM CART WHERE PRODUCTID = " + textBox1.Text.ToString();
            insertEmp.CommandType = CommandType.Text;
            int rows = insertEmp.ExecuteNonQuery();
            if (rows > 0)
                MessageBox.Show("Data DELETED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
            updateGrid();
        }
        bool insert2()
        {
            int quantity = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                if (textBox2.Text == dataGridView1.Rows[i].Cells[0].Value.ToString())
                {
                    quantity = int.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString());
                    break;
                }
            }
            if (int.Parse(numericUpDown1.Value.ToString()) < quantity)
            {
                quantity -= int.Parse(numericUpDown1.Value.ToString());
                con.Open();
                OracleCommand updateCmd = con.CreateCommand();
                updateCmd.CommandText = "UPDATE PRODUCT SET QUANTITY = QUANTITY + " + quantity + " WHERE PRODUCTID = " + textBox2.Text;
                updateCmd.CommandType = CommandType.Text;
                updateCmd.ExecuteNonQuery();
                con.Close();
                return true;
            }
            else
            {
                int quan = 0;
                con.Open();
                string query = "SELECT QUANTITY FROM PRODUCT WHERE PRODUCTID = " + textBox2.Text;
                OracleCommand cmd = new OracleCommand(query, con);
                OracleDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    quan = dr.GetInt32(0);
                }
                con.Close();
                quan += quantity;
                quantity = int.Parse(numericUpDown1.Value.ToString());
                if (quan >= quantity)
                {
                    quan -= quantity;
                    con.Open();
                    OracleCommand updateCmd = con.CreateCommand();
                    updateCmd.CommandText = "UPDATE PRODUCT SET QUANTITY = " + quan + " WHERE PRODUCTID = " + textBox2.Text;
                    updateCmd.CommandType = CommandType.Text;
                    updateCmd.ExecuteNonQuery();
                    con.Close();
                    return true;
                }
                else
                {
                    MessageBox.Show("Not enough quantity available.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
        }
        void delete()
        {
            con.Open();
            OracleCommand insertEmp = con.CreateCommand();
            insertEmp.CommandText = "DELETE FROM CART WHERE QUANTITY = 0";
            int rows = insertEmp.ExecuteNonQuery();
            con.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            bool flag = insert2();
            if(flag)
            {
                con.Open();
                OracleCommand insertEmp = con.CreateCommand();
                insertEmp.CommandText = "UPDATE CART SET QUANTITY = " + numericUpDown1.Value.ToString() + " WHERE PRODUCTID = " + textBox2.Text.ToString() + "";
                int rows = insertEmp.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("Data UPDATED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                delete();
                updateGrid();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label1.Text != "0")
            {
                this.Hide();
                Pay p = new Pay();
                ((Label)p.Controls["label1"]).Text = label1.Text;
                p.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please buy something first.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                CustomerRes res = new CustomerRes();
                res.ShowDialog();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked==true)
            {
                label2.Enabled = true;
                textBox1.Enabled = true;
                button1.Enabled = true;
                label3.Enabled = false;
                label4.Enabled = false;
                textBox2.Enabled = false;
                numericUpDown1.Enabled = false;
                button2.Enabled = false;
            }
            else
            {
                label2.Enabled = false;
                textBox1.Enabled = false;
                button1.Enabled = false;
                label3.Enabled = true;
                label4.Enabled = true;
                textBox2.Enabled = true;
                numericUpDown1.Enabled = true;
                button2.Enabled = true;
            }
        }
    }
}
