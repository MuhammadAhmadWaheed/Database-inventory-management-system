﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class ManageProductsShopK : Form
    {
        OracleConnection con;
        public ManageProductsShopK()
        {
            InitializeComponent();
        }
        bool checkDate()
        {
            if (textBox4.Text.Length != 10)
                return false;
            else if (textBox4.Text[2] == '/' && textBox4.Text[5] == '/')
            {
                int day = 0, month = 0, year = 0;
                day += (textBox4.Text[3] - '0');
                day *= 10;
                day += (textBox4.Text[4] - '0');
                month += (textBox4.Text[0] - '0');
                month *= 10;
                month += (textBox4.Text[1] - '0');
                for (int i = 0; i < 4; i++)
                {
                    year *= 10;
                    year += (textBox4.Text[i + 6] - '0');
                }
                if (year >= 2023 && year <= 2026)
                {
                    if ((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && day > 0 && day <= 31)
                        return true;
                    else
                if (month == 4 || month == 6 || month == 9 || month == 11 && day > 0 && day <= 30)
                        return true;
                    else
                       if (month == 2)
                    {
                        if ((year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) && day > 0 && day <= 29)
                            return true;
                        else if (day > 0 && day <= 28)
                            return true;
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }
        bool check(bool flag)
        {
            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                if (!(textBox1.Text[i] - '0' >= 0 && textBox1.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ProductID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            if (flag)
            {
                for (int i = 0; i < textBox2.Text.Length; i++)
                {
                    if (textBox2.Text[i] >= 'A' && textBox2.Text[i] <= 'Z' || textBox2.Text[i] >= 'a' && textBox2.Text[i] <= 'z' || textBox2.Text[i] == ' ')
                        continue;
                    else
                    {
                        flag = false;
                        MessageBox.Show("Invalid ProductName.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
            }
            if (flag)
            {
                for (int i = 0; i < textBox3.Text.Length; i++)
                {
                    if (textBox3.Text[i] >= 'A' && textBox3.Text[i] <= 'Z' || textBox3.Text[i] >= 'a' && textBox3.Text[i] <= 'z' || textBox3.Text[i] == ' ')
                        continue;
                    else
                    {
                        flag = false;
                        MessageBox.Show("Invalid ManufacturerName.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
            }
            if (flag)
            {
                flag = checkDate();
                if (!flag)
                {
                    MessageBox.Show("Please enter a valid ExpiryDate.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (flag)
            {
                if (textBox5.Text[0] - '0' == 0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    for (int i = 0; i < textBox5.Text.Length && textBox5.Text[0] - '0' != 0; i++)
                    {
                        if (!(textBox5.Text[i] - '0' >= 0 && textBox5.Text[i] - '0' <= 9))
                        {
                            flag = false;
                            MessageBox.Show("Invalid Price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
            }
            if(flag)
            {
                if (numericUpDown1.Value <= 0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Quantity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            return flag;
        }
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            ShopKeeperLogin login = new ShopKeeperLogin();
            login.ShowDialog();
        }

        private void ManageProductsShopK_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            updateGrid();
            numericUpDown1.Maximum = 1000;
        }
        private void updateGrid()
        {
            con.Open();
            OracleCommand getEmps = con.CreateCommand();
            getEmps.CommandText = "SELECT PRODUCTID,PRODUCTNAME,MANUFACTURERNAME,EXPIRYDATE,PRICE,QUANTITY FROM PRODUCT WHERE USERNAME = \'" + label7.Text.ToString() + "\'";
            getEmps.CommandType = CommandType.Text;
            OracleDataReader empDR = getEmps.ExecuteReader();
            DataTable empDT = new DataTable();
            empDT.Load(empDR);
            dataGridView1.DataSource = empDT;
            con.Close();
        }
        bool checkDuplicate()
        {
            int id = Int16.Parse(textBox1.Text);
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT PRODUCTNAME FROM PRODUCT WHERE PRODUCTID = " + id + "";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Product ID is already present in the table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                try
                {
                    bool flag = true;
                    flag = check(flag);
                    if (flag && checkDuplicate())
                    {
                        con.Open();
                        OracleCommand insertEmp = con.CreateCommand();
                        insertEmp.CommandText = "INSERT INTO PRODUCT VALUES(" + textBox1.Text + ",'" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "'," + textBox5.Text + ",'" + label7.Text.ToString() + "'," + numericUpDown1.Value + ")";
                        insertEmp.CommandType = CommandType.Text;
                        int rows = insertEmp.ExecuteNonQuery();
                        if (rows > 0)
                            MessageBox.Show("Data INSERTED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        con.Close();
                        updateGrid();
                        textBox1.Clear();
                        textBox2.Clear();
                        textBox3.Clear();
                        textBox4.Clear();
                        textBox5.Clear();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while performing the operation: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field.", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            { 
                bool flag = true;
                flag = check(flag);
                if (flag)
                {
                    con.Open();
                    OracleCommand insertEmp = con.CreateCommand();
                    insertEmp.CommandText = "UPDATE PRODUCT SET PRODUCTNAME = \'" + textBox2.Text.ToString() + "\', MANUFACTURERNAME = \'" + textBox3.Text.ToString()
                        + "\', EXPIRYDATE = \'" + textBox4.Text.ToString() + "\', PRICE = " + textBox5.Text.ToString() + ", QUANTITY = " + numericUpDown1.Value + " WHERE PRODUCTID = " + textBox1.Text.ToString() + "";
                    int rows = insertEmp.ExecuteNonQuery();
                    if (rows > 0)
                        MessageBox.Show("Data UPDATED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    updateGrid();
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(textBox1.Text.Length==0)
            {
                MessageBox.Show("ProductID must be entered to delete a product.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.Open();
                OracleCommand insertEmp = con.CreateCommand();
                insertEmp.CommandText = "DELETE FROM PRODUCT WHERE PRODUCTID = " + textBox1.Text.ToString();
                insertEmp.CommandType = CommandType.Text;
                int rows = insertEmp.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("Data DELETED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                updateGrid();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox4_Enter(object sender, EventArgs e)
        {
            if (textBox4.Text == "MM/DD/YYYY")
            {
                textBox4.Text = "";
                textBox4.ForeColor = Color.Black;
            }
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            if (textBox4.Text == "")
            {
                textBox4.Text = "MM/DD/YYYY";
                textBox4.ForeColor = Color.Silver;
            }
        }

        private void Search_Enter(object sender, EventArgs e)
        {
            if (Search.Text == "Search Products Here")
            {
                Search.Text = "";
                Search.ForeColor = Color.Black;
            }
        }

        private void Search_Leave(object sender, EventArgs e)
        {
            if (Search.Text == "")
            {
                Search.Text = "Search Products Here";
                Search.ForeColor = Color.Silver;
            }
        }

        private void Search_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Search.Text != "")
            {
                OracleCommand cmd = new OracleCommand("SELECT PRODUCTID,PRODUCTNAME,MANUFACTURERNAME,EXPIRYDATE,PRICE FROM PRODUCT WHERE CONCAT(PRODUCTID,CONCAT(PRODUCTNAME,CONCAT(MANUFACTURERNAME,CONCAT(EXPIRYDATE,PRICE)))) LIKE '%" + Search.Text.ToString() + "%' AND USERNAME = \'" + label7.Text.ToString() + "\'", con);
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
                updateGrid();
        }
    }
}
