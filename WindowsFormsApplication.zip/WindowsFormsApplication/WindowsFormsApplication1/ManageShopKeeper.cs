﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class ManageShopKeeper : Form
    {
        OracleConnection con;
        public ManageShopKeeper()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ManageShopKeeper_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            updateGrid();
        }
        bool check(bool flag)
        {
            for (int i = 0; i < textBox3.Text.Length; i++)
            {
                if (!(textBox3.Text[i] - '0' >= 0 && textBox3.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ShopID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            if (flag)
            {
                if (textBox5.Text.Length != 11)
                    flag = false;
                if (textBox5.Text[0] == '0' && textBox5.Text[1] == '3')
                {
                    for (int i = 2; i < textBox5.Text.Length; i++)
                    {
                        if (!(textBox5.Text[i] - '0' >= 0 && textBox5.Text[i] - '0' <= 9))
                        {
                            flag = false;
                            MessageBox.Show("Invalid Contact.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
                else
                {
                    flag = false;
                    MessageBox.Show("Invalid Contact.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (flag)
            {
                if (textBox6.Text[0] - '0' == 0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Salary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    for (int i = 0; i < textBox6.Text.Length && textBox6.Text[0] - '0' != 0; i++)
                    {
                        if (!(textBox6.Text[i] - '0' >= 0 && textBox6.Text[i] - '0' <= 9))
                        {
                            flag = false;
                            MessageBox.Show("Invalid Salary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
            }
            if (flag)
            {
                for (int i = 0; i < textBox4.Text.Length; i++)
                {
                    if (textBox4.Text[i] >= 'A' && textBox4.Text[i] <= 'Z' || textBox4.Text[i] >= 'a' && textBox4.Text[i] <= 'z' || textBox4.Text[i] == ' ')
                        continue;
                    else
                    {
                        flag = false;
                        MessageBox.Show("Invalid ShopKeeperName.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
            }
            return flag;
        }
        bool checkDuplicate()
        {
            int id = Int16.Parse(textBox3.Text);
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT SALARY FROM SHOPKEEPER WHERE SHOPID = " + id + "";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Shop ID is already present in the table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkUsername()
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT PRODUCTNAME FROM SHOPKEEPER WHERE USERNAME = \'" + textBox1.Text.ToString() + "\'";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Username is already taken.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkPassword()
        {
            if (textBox2.Text.Length < 8)
            {
                MessageBox.Show("Password must contain at least one small letter,one capital letter,one number and one symbol and should be greater than 8 charaters."
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            bool salph = false, calph = false, num = false, sym = false;
            for (int i = 0; i < textBox2.Text.Length; i++)
            {
                if (textBox2.Text[i] >= 'a' && textBox2.Text[i] <= 'z')
                    salph = true;
                else if (textBox2.Text[i] >= 'A' && textBox2.Text[i] <= 'Z')
                    calph = true;
                else if (textBox2.Text[i] >= '0' && textBox2.Text[i] <= '9')
                    num = true;
                else if (textBox2.Text[i] == '!' || textBox2.Text[i] == '@' || textBox2.Text[i] == '#' || textBox2.Text[i] == '$' || textBox2.Text[i] == ',' || textBox2.Text[i] == '*')
                    sym = true;
            }
            if (salph && calph && num && sym)
                return true;
            MessageBox.Show("Password must contain at least one small letter,one capital letter,one number and one symbol and should be greater than 8 charaters."
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0
                || textBox6.Text.Length == 0 || textBox7.Text.Length == 0 || textBox8.Text.Length == 0)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                bool flag = true;
                flag = check(flag);
                if (flag)
                {
                    if(checkDuplicate() && checkUsername()&& checkPassword())
                    {
                        con.Open();
                        OracleCommand insertEmp = con.CreateCommand();
                        insertEmp.CommandText = "INSERT INTO SHOPKEEPER VALUES('" + textBox1.Text + "','" + textBox2.Text + "'," + textBox3.Text + ",'" + textBox4.Text +
                            "'," + textBox5.Text + "," + textBox6.Text + ",'" + textBox7.Text + "','" + textBox8.Text + "')";
                        insertEmp.CommandType = CommandType.Text;
                        int rows = insertEmp.ExecuteNonQuery();
                        if (rows > 0)
                            MessageBox.Show("Data Inserted Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        con.Close();
                        updateGrid();
                        textBox1.Clear();
                        textBox2.Clear();
                        textBox3.Clear();
                        textBox4.Clear();
                        textBox5.Clear();
                        textBox6.Clear();
                        textBox7.Clear();
                        textBox8.Clear();
                    }
                }
            }
        }
        private void updateGrid()
        {
            con.Open();
            OracleCommand getEmps = con.CreateCommand();
            getEmps.CommandText = "SELECT * FROM SHOPKEEPER";
            getEmps.CommandType = CommandType.Text;
            OracleDataReader empDR = getEmps.ExecuteReader();
            DataTable empDT = new DataTable();
            empDT.Load(empDR);
            dataGridView1.DataSource = empDT;
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0
                || textBox6.Text.Length == 0 || textBox7.Text.Length == 0 || textBox8.Text.Length == 0)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                bool flag = true;
                flag = check(flag);
                if (flag && checkUsername()&&checkPassword())
                {
                    con.Open();
                    OracleCommand insertEmp = con.CreateCommand();
                    insertEmp.CommandText = "UPDATE SHOPKEEPER SET USERNAME = \'" + textBox1.Text + "\', PASSWORD = \'" + textBox2.Text + "\', SHOPKEEPERNAME = \'"
                        + textBox4.Text + "\', CONTACT = " + textBox5.Text + ", SALARY = " + textBox6.Text + ", LOCATION = \'" + textBox7.Text + "\', SHOPNAME = \'" + textBox8.Text
                        + "\' WHERE SHOPID = " + textBox3.Text + "";
                    int rows = insertEmp.ExecuteNonQuery();
                    if (rows > 0)
                        MessageBox.Show("Data Updated Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    updateGrid();
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox3.Text.Length == 0)
            {
                MessageBox.Show("To delete shopkeeper Shop Id must be entered.", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.Open();
                OracleCommand insertEmp = con.CreateCommand();
                insertEmp.CommandText = "DELETE FROM SHOPKEEPER WHERE SHOPID = " + textBox3.Text.ToString();
                insertEmp.CommandType = CommandType.Text;
                int rows = insertEmp.ExecuteNonQuery();
                if (rows > 0)
                    MessageBox.Show("Data DELETED Successfully.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                updateGrid();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminRes res = new AdminRes();
            res.ShowDialog();
        }

        private void Search_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (Search.Text != "")
            {
                OracleCommand cmd = new OracleCommand("SELECT * FROM SHOPKEEPER WHERE CONCAT(USERNAME,CONCAT(PASSWORD,CONCAT(SHOPID,CONCAT(SHOPKEEPERNAME,CONCAT(CONTACT,CONCAT(SALARY,CONCAT(LOCATION,SHOPNAME))))))) LIKE '%" + Search.Text.ToString() + "%'", con) ;
                OracleDataAdapter da = new OracleDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            else
                updateGrid();
        }

        private void Search_Enter(object sender, EventArgs e)
        {
            if (Search.Text == "Search ShopKeeper Here")
            {
                Search.Text = "";
                Search.ForeColor = Color.Black;
            }
        }

        private void Search_Leave(object sender, EventArgs e)
        {
            if (Search.Text == "")
            {
                Search.Text = "Search ShopKeeper Here";
                Search.ForeColor = Color.Silver;
            }
        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "03XXXXXXXXX")
            {
                textBox5.Text = "";
                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "03XXXXXXXXX";
                textBox5.ForeColor = Color.Silver;
            }
        }
    }
}
