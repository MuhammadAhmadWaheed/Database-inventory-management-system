﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class Pay : Form
    {
        OracleConnection con;
        public Pay()
        {
            InitializeComponent();
        }

        private void Pay_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
            label3.Enabled = true;
            textBox1.Enabled = true;
            label4.Enabled = false;
            textBox2.Enabled = false;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                label3.Enabled = true;
                textBox1.Enabled = true;
                label4.Enabled = false;
                textBox2.Enabled = false;
            }
            else
            {
                label3.Enabled = false;
                textBox1.Enabled = false;
                label4.Enabled = true;
                textBox2.Enabled = true;
            }
        }
        bool checkCardNumber()
        {
            if (textBox1.Text.Length == 19)
            {
                if (textBox1.Text[4] == '-' && textBox1.Text[9] == '-' && textBox1.Text[14] == '-')
                {
                    for (int i = 0; i < textBox1.Text.Length; i++)
                    {
                        if (i == 4 || i == 9 || i == 14)
                            continue;
                        else
                        {
                            if (!(textBox1.Text[i] >= '0' && textBox1.Text[i] <= '9'))
                                return false;
                        }
                    }
                }
                else
                    return false;
            }
            else
                return false;
            return true;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Payment p = new Payment();
            p.ShowDialog();
        }
        void delete()
        {
            con.Open();
            OracleCommand insertEmp = con.CreateCommand();
            insertEmp.CommandText = "DELETE FROM PRODUCT WHERE QUANTITY = 0";
            int rows = insertEmp.ExecuteNonQuery();
            con.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if(radioButton2.Checked==true)
            {
                int total = int.Parse(textBox2.Text) - int.Parse(label1.Text);
                if (total >= 0)
                {
                    delete();
                    con.Open();
                    string query = "TRUNCATE TABLE CART";
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Payment Paid. Thanks for your visit.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    CustomerRes res = new CustomerRes();
                    res.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Payment Error.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    Payment p = new Payment();
                    p.ShowDialog();
                }
            }
            else
            {
                bool flag = true;
                flag = checkCardNumber();
                if(flag)
                {
                    con.Open();
                    string query = "TRUNCATE TABLE CART";
                    OracleCommand cmd = new OracleCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Payment Paid. Thanks for your visit.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    CustomerRes res = new CustomerRes();
                    res.ShowDialog();
                }
                else
                {

                    MessageBox.Show("Please enter a valid card number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if (textBox1.Text == "XXXX-XXXX-XXXX-XXXX")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "XXXX-XXXX-XXXX-XXXX";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
