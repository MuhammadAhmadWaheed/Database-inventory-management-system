﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class Admin_Login : Form
    {
        OracleConnection con;
        public Admin_Login()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Admin_Login_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=AHMAD;PASSWORD=12345";
            con = new OracleConnection(conStr);
            textBox2.UseSystemPasswordChar = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AdminUsername.Text.Trim() == string.Empty || textBox2.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Please fill out all fields.", "Required Field", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                con.Open();
                OracleCommand adminLog = con.CreateCommand();
                adminLog.CommandText = "SELECT * FROM ADMIN where Username = \'" + AdminUsername.Text.ToString() + "\'and Password =  \'" + textBox2.Text.ToString() + "\'";
                adminLog.CommandType = CommandType.Text;
                OracleDataReader d = adminLog.ExecuteReader();
                if (d.Read())
                {
                    this.Hide();
                    AdminRes form = new AdminRes();
                    form.ShowDialog();
                    this.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                con.Close();
                AdminUsername.Clear();
                textBox2.Clear();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                textBox2.UseSystemPasswordChar = false;
            else
                textBox2.UseSystemPasswordChar = true;
        }
    }
}
