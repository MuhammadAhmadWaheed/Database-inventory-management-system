﻿namespace WindowsFormsApplication1
{
    partial class ShopKeeperSignUp1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShopKeeperSignUp1));
            this.label1 = new System.Windows.Forms.Label();
            this.Username = new System.Windows.Forms.Label();
            this.Password = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.NextStep = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.ShopName = new System.Windows.Forms.Label();
            this.ShopLocation = new System.Windows.Forms.Label();
            this.Salary = new System.Windows.Forms.Label();
            this.Contact = new System.Windows.Forms.Label();
            this.ShopKeeperName = new System.Windows.Forms.Label();
            this.ShopID = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(296, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(404, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome To Sign Up Form";
            // 
            // Username
            // 
            this.Username.AutoSize = true;
            this.Username.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Username.Location = new System.Drawing.Point(136, 159);
            this.Username.Name = "Username";
            this.Username.Size = new System.Drawing.Size(95, 23);
            this.Username.TabIndex = 2;
            this.Username.Text = "Username";
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Password.Location = new System.Drawing.Point(470, 159);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(90, 23);
            this.Password.TabIndex = 3;
            this.Password.Text = "Password";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(292, 159);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(145, 22);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(653, 161);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(157, 22);
            this.textBox2.TabIndex = 6;
            this.textBox2.UseSystemPasswordChar = true;
            this.textBox2.TextChanged += new System.EventHandler(this.Pass_TextChanged);
            // 
            // NextStep
            // 
            this.NextStep.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.NextStep.Font = new System.Drawing.Font("Monotype Corsiva", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.NextStep.Location = new System.Drawing.Point(432, 441);
            this.NextStep.Name = "NextStep";
            this.NextStep.Size = new System.Drawing.Size(110, 39);
            this.NextStep.TabIndex = 17;
            this.NextStep.Text = "Sign Up";
            this.NextStep.UseVisualStyleBackColor = false;
            this.NextStep.Click += new System.EventHandler(this.NextStep_Click_1);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(653, 366);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(157, 22);
            this.textBox8.TabIndex = 29;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(284, 366);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(165, 22);
            this.textBox7.TabIndex = 28;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(653, 294);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(157, 22);
            this.textBox6.TabIndex = 27;
            // 
            // textBox5
            // 
            this.textBox5.ForeColor = System.Drawing.Color.Silver;
            this.textBox5.Location = new System.Drawing.Point(292, 294);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(137, 22);
            this.textBox5.TabIndex = 26;
            this.textBox5.Text = "03XXXXXXXXX";
            this.textBox5.Enter += new System.EventHandler(this.textBox5_Enter);
            this.textBox5.Leave += new System.EventHandler(this.textBox5_Leave);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(653, 224);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(157, 22);
            this.textBox4.TabIndex = 25;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(292, 224);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(137, 22);
            this.textBox3.TabIndex = 24;
            // 
            // ShopName
            // 
            this.ShopName.AutoSize = true;
            this.ShopName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.ShopName.Location = new System.Drawing.Point(470, 364);
            this.ShopName.Name = "ShopName";
            this.ShopName.Size = new System.Drawing.Size(105, 23);
            this.ShopName.TabIndex = 23;
            this.ShopName.Text = "Shop Name";
            // 
            // ShopLocation
            // 
            this.ShopLocation.AutoSize = true;
            this.ShopLocation.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.ShopLocation.Location = new System.Drawing.Point(136, 364);
            this.ShopLocation.Name = "ShopLocation";
            this.ShopLocation.Size = new System.Drawing.Size(130, 23);
            this.ShopLocation.TabIndex = 22;
            this.ShopLocation.Text = "Shop Location";
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Salary.Location = new System.Drawing.Point(470, 292);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(64, 23);
            this.Salary.TabIndex = 21;
            this.Salary.Text = "Salary";
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.Contact.Location = new System.Drawing.Point(136, 292);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(77, 23);
            this.Contact.TabIndex = 20;
            this.Contact.Text = "Contact";
            // 
            // ShopKeeperName
            // 
            this.ShopKeeperName.AutoSize = true;
            this.ShopKeeperName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.ShopKeeperName.Location = new System.Drawing.Point(470, 222);
            this.ShopKeeperName.Name = "ShopKeeperName";
            this.ShopKeeperName.Size = new System.Drawing.Size(167, 23);
            this.ShopKeeperName.TabIndex = 19;
            this.ShopKeeperName.Text = "ShopKeeper Name";
            // 
            // ShopID
            // 
            this.ShopID.AutoSize = true;
            this.ShopID.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ShopID.Location = new System.Drawing.Point(136, 222);
            this.ShopID.Name = "ShopID";
            this.ShopID.Size = new System.Drawing.Size(72, 23);
            this.ShopID.TabIndex = 18;
            this.ShopID.Text = "ShopID";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 482);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 33);
            this.button1.TabIndex = 30;
            this.button1.Text = "Go Back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ShopKeeperSignUp1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(980, 527);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.ShopName);
            this.Controls.Add(this.ShopLocation);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.ShopKeeperName);
            this.Controls.Add(this.ShopID);
            this.Controls.Add(this.NextStep);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Username);
            this.Controls.Add(this.label1);
            this.Name = "ShopKeeperSignUp1";
            this.Text = "ShopKeeperSignUp1";
            this.Load += new System.EventHandler(this.ShopKeeperSignUp1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Username;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button NextStep;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label ShopName;
        private System.Windows.Forms.Label ShopLocation;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.Label ShopKeeperName;
        private System.Windows.Forms.Label ShopID;
        private System.Windows.Forms.Button button1;
    }
}