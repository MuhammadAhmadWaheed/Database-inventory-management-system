﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
namespace WindowsFormsApplication1
{
    public partial class ShopKeeperSignUp1 : Form
    {
        OracleConnection con;
        public ShopKeeperSignUp1()
        {
            InitializeComponent();
        }

        private void ShopKeeperSignUp1_Load(object sender, EventArgs e)
        {
            string conStr = @"DATA SOURCE = localhost:1521/xe;USER ID=F219078;PASSWORD=1234";
            con = new OracleConnection(conStr);
        }
        bool check(bool flag)
        {
            for (int i = 0; i < textBox3.Text.Length; i++)
            {
                if (!(textBox3.Text[i] - '0' >= 0 && textBox3.Text[i] - '0' <= 9))
                {
                    flag = false;
                    MessageBox.Show("Invalid ShopID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    break;
                }
            }
            if (flag)
            {
                for (int i = 0; i < textBox4.Text.Length; i++)
                {
                    if (textBox4.Text[i] >= 'A' && textBox4.Text[i] <= 'Z' || textBox4.Text[i] >= 'a' && textBox4.Text[i] <= 'z' || textBox4.Text[i] == ' ')
                        continue;
                    else
                    {
                        flag = false;
                        MessageBox.Show("Invalid ShopKeeperName.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    }
                }
            }
            if (flag)
            {
                if (textBox5.Text.Length != 11)
                    flag = false;
                if (textBox5.Text[0] == '0' && textBox5.Text[1] == '3')
                {
                    for (int i = 2; i < textBox5.Text.Length; i++)
                    {
                        if (!(textBox5.Text[i] - '0' >= 0 && textBox5.Text[i] - '0' <= 9))
                        {
                            flag = false;
                            MessageBox.Show("Invalid Contact.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
                else
                {
                    flag = false;
                    MessageBox.Show("Invalid Contact.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            if (flag)
            {
                if (textBox6.Text[0] - '0' == 0)
                {
                    flag = false;
                    MessageBox.Show("Invalid Salary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    for (int i = 0; i < textBox6.Text.Length && textBox6.Text[0] - '0' != 0; i++)
                    {
                        if (!(textBox6.Text[i] - '0' >= 0 && textBox6.Text[i] - '0' <= 9))
                        {
                            flag = false;
                            MessageBox.Show("Invalid Salary.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            break;
                        }
                    }
                }
            }
            return flag;
        }
        bool checkDuplicate()
        {
            int id = Int16.Parse(textBox3.Text);
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT SALARY FROM SHOPKEEPER WHERE SHOPID = " + id + "";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Shop ID is already present in the table.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkUsername()
        {
            con.Open();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT CONTACT FROM SHOPKEEPER WHERE USERNAME = \'" + textBox1.Text.ToString() + "\'";
            cmd.CommandType = CommandType.Text;
            OracleDataReader d = cmd.ExecuteReader();
            if (d.Read())
            {
                MessageBox.Show("Username is already taken.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                con.Close();
                return false;
            }
            con.Close();
            return true;
        }
        bool checkPassword()
        {
            if (textBox2.Text.Length < 8)
            {
                MessageBox.Show("Password must contain at least one small letter,one capital letter,one number and one symbol and should be greater than 8 charaters."
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            bool salph = false, calph = false, num = false, sym = false;
            for (int i = 0; i < textBox2.Text.Length; i++)
            {
                if (textBox2.Text[i] >= 'a' && textBox2.Text[i] <= 'z')
                    salph = true;
                else if (textBox2.Text[i] >= 'A' && textBox2.Text[i] <= 'Z')
                    calph = true;
                else if (textBox2.Text[i] >= '0' && textBox2.Text[i] <= '9')
                    num = true;
                else if (textBox2.Text[i] == '!' || textBox2.Text[i] == '@' || textBox2.Text[i] == '#' || textBox2.Text[i] == '$' || textBox2.Text[i] == ',' || textBox2.Text[i] == '*')
                    sym = true;
            }
            if (salph && calph && num && sym)
                return true;
            MessageBox.Show("Password must contain at least one small letter,one capital letter,one number and one symbol and should be greater than 8 charaters."
                    , "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return false;
        }
        private void NextStep_Click_1(object sender, EventArgs e)
        {
            try
            {
                bool flag = true;
                flag = check(flag);
                if(flag && checkDuplicate() && checkUsername() && checkPassword())
                {
                    con.Open();
                    string query = "INSERT INTO SHOPKEEPER VALUES('" + textBox1.Text + "','" + textBox2.Text + "'," + textBox3.Text + ",'" + textBox4.Text + "'," +
                        textBox5.Text + "," + textBox6.Text + ",'" + textBox7.Text + "','" + textBox8.Text + "')";
                    OracleCommand cmd = new OracleCommand(query, con);
                    int rows = cmd.ExecuteNonQuery();
                    if (rows > 0)
                        MessageBox.Show("Sign Up Completed.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    con.Close();
                    this.Hide();
                    ShopKeeperLogin login = new ShopKeeperLogin();
                    login.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while performing the operation: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            ShopKeeperLogin login = new ShopKeeperLogin();
            login.ShowDialog();
        }

        private void Pass_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_Enter(object sender, EventArgs e)
        {
            if (textBox5.Text == "03XXXXXXXXX")
            {
                textBox5.Text = "";
                textBox5.ForeColor = Color.Black;
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                textBox5.Text = "03XXXXXXXXX";
                textBox5.ForeColor = Color.Silver;
            }
        }
    }
}
